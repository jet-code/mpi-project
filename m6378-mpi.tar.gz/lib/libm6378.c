/*
 * > cc -c -O5 libm6378.c
 * > ar rcs libm6378.a libm6378.o
 * ==> libm6378.a
 */

#define _LIBM6378_C_
#include "m6378.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>     /* memset, memcpy. */

#include <sys/types.h>  /* socket, connect,              */
#include <sys/socket.h> /* && send, recv (when defined). */
#include <netdb.h>      /* gethostbyname || getaddrinfo. */
#include <unistd.h>     /* write, read, close.           */

#include <netinet/tcp.h> /* IPPROTO_TCP, TCP_NODELAY */

#ifndef MIN
# define MIN(a,b) ((a)<(b)?(a):(b))
#endif

static 
struct _ClientInfo {
  int   nproc;
  char  *gid;
  int   rank;
  char  **srvhosts;
  int   nsrvhosts;
  int   *id2srvid;
  int   *srvsock;
  char  *buf;
  int   bufsz;
} clientinfo;
#define INIT_BUFSZ 1024 /* Initial size allocated to ws *buf above. */

#define WRITE(fd,buf,num) send(fd,buf,num,0)
#define  READ(fd,buf,num) recv(fd,buf,num,0)
#define FLUSH(fd) 
/* Someday might want to implement some kind of socket output flush. */

/* In case we want to use obsolete net routine: #define USE_GETHOSTBYNAME */

static
int makeHostList( int nhosts, char **hosts, char ***newptr, int **offptr ) {
  int n, *off = (int*)0, nnew;
  char **ws = (char**)0, **new = (char**)0;

  if( nhosts < 1 ) return(-1);
  if ( !(ws  = (char**)malloc(sizeof(char*)*nhosts)) ) goto ErrorCleanUp;
  if ( !(off =   (int*)malloc(  sizeof(int)*nhosts)) ) goto ErrorCleanUp;
  ws[0]  = hosts[0];
  off[0] = 0;
  nnew = 1;
  for( n = 1; n < nhosts; n++ ) {
    int k;
    for( k = 0; k < nnew; k++ ) {
      if( strcmp( hosts[n], ws[k] ) == 0 ) break;
    }
    if( k == nnew ) {
      ws[k] = hosts[n];
      nnew = k+1;
    }
    off[n] = k;
  }
  if ( !(new = (char**)malloc(sizeof(char*)*nnew)) ) goto ErrorCleanUp;
  memcpy( new, ws, sizeof(char*)*nnew );
  free( ws );
  *newptr = new;
  *offptr = off;
  return(nnew);

ErrorCleanUp:
  if( ws )  free(ws);
  if( off ) free(off);
  if( new ) free(new);
  return(0);
}


int M6378_Init( int *argc, char **argv ) {
  int sz, n, nargv = *argc;

  memset( &clientinfo, 0, sizeof(clientinfo) );
  if( nargv < 3 ) {
    fprintf( stderr, "M6378_Init: %s invoked with insufficient or invalid program arguments.\n", argv[0] );
    return(0);
  }
  clientinfo.nproc = atoi(argv[nargv-3]);
  clientinfo.rank  = atoi(argv[nargv-1]);
  if( clientinfo.nproc < 1
   || clientinfo.rank < 0 || clientinfo.rank >= clientinfo.nproc
   || nargv-3-clientinfo.nproc < 1 ) {
    fprintf( stderr, "M6378_Init: %s invoked with insufficient or invalid program arguments.\n", argv[0] );
    return(0);
  }
  sz = strlen( argv[nargv-2] );
  clientinfo.gid = (char*)malloc( sz+1 );
  if( !clientinfo.gid ) {
    fprintf( stderr, "M6378_Init(%d): Memory allocation error.\n", clientinfo.rank );
    goto ErrorCleanUp;
  }
  memcpy( clientinfo.gid, argv[nargv-2], sz );
  clientinfo.gid[sz] = '\0';
  /* Careful. This reuses pointers from argv array. */
  sz = makeHostList( clientinfo.nproc,
                     &argv[nargv-(3+clientinfo.nproc)],
                     &clientinfo.srvhosts,
                     &clientinfo.id2srvid );
  if( sz <= 0 ) {
    fprintf( stderr, "M6378_Init(%d): Memory allocation error.\n", clientinfo.rank );
    goto ErrorCleanUp;
  }
  clientinfo.nsrvhosts = sz;
  clientinfo.srvsock = (int*)malloc( sizeof(int)*clientinfo.nsrvhosts ); 
  if( !clientinfo.srvsock ) {
    fprintf( stderr, "M6378_Init(%d): Memory allocation error.\n", clientinfo.rank );
    goto ErrorCleanUp;
  }
  for( n = 0; n < clientinfo.nsrvhosts; n++ ) {clientinfo.srvsock[n] = -1;}
  clientinfo.buf = (char*)malloc( INIT_BUFSZ ); 
  if( !clientinfo.buf ) {
    fprintf( stderr, "M6378_Init(%d): Memory allocation error.\n", clientinfo.rank );
    goto ErrorCleanUp;
  }
  clientinfo.bufsz = INIT_BUFSZ;
  *argc = nargv-3-clientinfo.nproc;
  /* Don't buffer stdout and stderr. Using this instead of explicit fflush(). */
  setvbuf( stdout, NULL, _IONBF, 0 );
  setvbuf( stderr, NULL, _IONBF, 0 ); /* This is default for stderr. */
  return(1);

ErrorCleanUp:
  if( clientinfo.gid )      free( clientinfo.gid );
  if( clientinfo.srvhosts ) free( clientinfo.srvhosts );
  if( clientinfo.id2srvid ) free( clientinfo.id2srvid );
  if( clientinfo.srvsock )  free( clientinfo.srvsock );
  if( clientinfo.buf )      free( clientinfo.buf );
  return(0);
}


void M6378_Finalize() {
  /* Clean up resources. */
  if( clientinfo.srvsock ) {
    int srvid;
    for( srvid = 0; srvid < clientinfo.nsrvhosts; srvid++ ) {
      if( clientinfo.srvsock[srvid] != -1 ) close( clientinfo.srvsock[srvid] );
    }
    free( clientinfo.srvsock );
  }
  if( clientinfo.gid )      free( clientinfo.gid );
  if( clientinfo.srvhosts ) free( clientinfo.srvhosts );
  if( clientinfo.id2srvid ) free( clientinfo.id2srvid );
  if( clientinfo.buf )      free( clientinfo.buf );
}


int M6378_Comm_size( int *nproc ) {
  *nproc = clientinfo.nproc;
  return(1);
}


int M6378_Comm_rank( int *rank ) {
  *rank = clientinfo.rank;
  return(1);
}


static
int getSocket( int id ) {
  int  sock;

  /* Only valid 0 <= id's < np should get here. */
  sock = clientinfo.srvsock[clientinfo.id2srvid[id]];
  if( sock == -1 ) {
    int  status, sz, value, len;
    struct sockaddr_in address;
    char *host = clientinfo.srvhosts[clientinfo.id2srvid[id]];

    sock = socket( AF_INET, SOCK_STREAM, 0 );
    if( sock < 0 ) {
      fprintf( stderr, "getSocket(%d): Could not create socket.\n",
                       clientinfo.rank );
      return(-1);
    }
    value = 1;
    setsockopt( sock, IPPROTO_TCP, TCP_NODELAY, (char*)&value, sizeof(int) );
    len = sizeof(int);
    getsockopt( sock, SOL_SOCKET, SO_SNDBUF, (char*)&value, &len );
    if( value > clientinfo.bufsz ) {
      if( clientinfo.buf ) free(clientinfo.buf);
      clientinfo.buf = (char*)malloc(value);
      if( !clientinfo.buf ) {
        clientinfo.bufsz = 0;
        fprintf( stderr, "getSocket(%d): Memory allocation error.\n",
                         clientinfo.rank );
        return(-1);
      }
      clientinfo.bufsz = value;
    }
#ifdef USE_GETHOSTBYNAME
    {
      /* gethostbyname is now obsolete. Use getaddrinfo (see below) instead. */
      struct hostent *phe;
      phe = gethostbyname( host );
      if( !phe ) {
        fprintf( stderr, "getSocket(%d): Could not get ip address for host %s.\n",
                         clientinfo.rank, host );
        close( sock );
        return(-1);
      }
      memset( &address, 0, sizeof(address) );
      address.sin_family = AF_INET;
      address.sin_addr.s_addr = *((unsigned long*)phe->h_addr_list[0]);
    }
#else
    {
      struct addrinfo hints, *result;
      memset( &hints, 0, sizeof(hints) );  
      hints.ai_family   = AF_INET; /* or AF_INET6 (vs AF_UNSPEC) to force version. */
      hints.ai_socktype = SOCK_STREAM;  
      if( getaddrinfo( host, (char*)0, &hints, &result ) != 0 ) {
        fprintf( stderr, "getSocket(%d): Could not get ip address for host %s.\n",
                         clientinfo.rank, host );
        close( sock );
        return(-1);
      }
      address = *( (struct sockaddr_in*)result->ai_addr );
      freeaddrinfo(result);
    }
#endif
    address.sin_port = htons(PORT);
    if( connect( sock, (struct sockaddr*)&address, sizeof(address) ) < 0 ) {
      fprintf( stderr, "getSocket(%d): Could not connect to host:port %s:%d.\n",
                       clientinfo.rank, host, PORT );
      close( sock );
      return(-1);
    }
    /* After connecting, let server know my identifier. */
    sprintf( clientinfo.buf, "%s:%d\n", clientinfo.gid, clientinfo.rank );
    sz = strlen(clientinfo.buf);
    status = WRITE( sock, clientinfo.buf, sz );
    if( status < sz ) {
      fprintf( stderr, "getSocket(%d): Socket write error.\n", clientinfo.rank );
      close( sock );
      return(-1);
    }
    FLUSH(sock);
    clientinfo.srvsock[clientinfo.id2srvid[id]] = sock;
  }
  return(sock);
}


int M6378_Isend( int id, char *data, int ndata ) {
  char *buf;
  int sock, status, sz, nadded;

  if( id < 0 || id >= clientinfo.nproc ) {
    fprintf( stderr, "M6378_Isend(%d): Specified id (%d) is invalid or out of range.\n",
                     clientinfo.rank, id );
    return(0);
  }
  sock = getSocket(id);
  if( sock == -1 ) {
    fprintf( stderr, "M6378_Isend(%d): Could not open socket to %d.\n", clientinfo.rank, id );
    return(0);
  }
  buf = clientinfo.buf;
  /* Send request. */
  sprintf( buf, "%d\n%s:%d\n%d\n\n", SEND, clientinfo.gid, id, ndata );
  sz = strlen(buf);
  /* Add as much data to buf as will fit. */
  nadded = MIN( clientinfo.bufsz-sz, ndata );
  memcpy( &buf[sz], data, nadded );
  sz    += nadded;
  data  += nadded;
  ndata -= nadded;
  status = WRITE( sock, buf, sz );
  if( status < sz ) {
    fprintf( stderr, "M6378_Isend(%d): Socket write error.\n", clientinfo.rank );
    return(0);
  }
  /* Keep writing until done. */
  while( ndata > 0 ) {
    status = WRITE( sock, data, ndata );
    if( status <= 0 ) {
      fprintf( stderr, "M6378_Isend(%d): Socket write error.\n", clientinfo.rank );
      return(0);
    }
    ndata -= status;
  }
  FLUSH(sock);
  return(1);
}


int M6378_Recv( int id, char *data, int *ndata ) {
  char *buf;
  int sock, n, status, sz, nread, total;

  if( id < 0 || id >= clientinfo.nproc ) {
    fprintf( stderr, "M6378_Recv(%d): Specified id (%d) is invalid or out of range.\n",
                     clientinfo.rank, id );
    return(0);
  }
  sock = getSocket( clientinfo.rank );
  if( sock == -1 ) {
    fprintf( stderr, "M6378_Recv(%d): Could not open socket to %d.\n", clientinfo.rank, clientinfo.rank );
    return(0);
  }
  buf = clientinfo.buf;
  /* Send request. */
  sprintf( buf, "%d\n%s:%d\n\n", RECV, clientinfo.gid, id );
  sz = strlen(buf);
  status = WRITE( sock, buf, sz );
  if( status < sz ) {
    fprintf( stderr, "M6378_Recv(%d): Socket write error.\n", clientinfo.rank );
    return(0);
  }
  FLUSH(sock);
  /* Read response. */
  status = READ( sock, buf, clientinfo.bufsz );  
  if( status < 0 ) {
    fprintf( stderr, "M6378_Recv(%d): Socket read error.\n", clientinfo.rank );
    return(0);
  }
  /* Pull off ascii 'total' (size of message) from header. */
  total = 0;
  for( n = 0; n < status; n++ ) {
    if( !(buf[n] == ' ' || buf[n] == '\t') )
      break;
  }
  for( ; n < status; n++ ) {
    if( buf[n] >= '0' && buf[n] <= '9' )
      total = 10*total + (buf[n]-'0');
    else
      break;
  }  
  for( ; n < status; n++ ) {
    if( buf[n] == '\n' ) 
      break;
    else
    if( !(buf[n] == ' ' || buf[n] == '\t') ) {
      fprintf( stderr, "M6378_Recv(%d): Corrupted message header.\n", clientinfo.rank );
      return(0);
    }
  }
  status -= n+1;
  /* Now total is known. */
  if( status < 0 ) {
    fprintf( stderr, "M6378_Recv(%d): Corrupted message header.\n", clientinfo.rank );
    return(0);
  }
  memcpy( &data[0], &buf[n+1], status );
  nread = status;
  /* Keep reading data until done. */
  while( nread < total ) {
    status = READ( sock, buf, MIN(clientinfo.bufsz,total-nread) );  
    if( status < 0 ) {
      fprintf( stderr, "M6378_Recv(%d): Socket read error.\n", clientinfo.rank );
      return(0);
    }
    memcpy( &data[nread], buf, status );
    nread += status;  
  }
  if( ndata ) *ndata = total;
  return(nread);
}


int M6378_Wait( int id ) {
  char *buf;
  int sock, status, sz;

  if( id < 0 || id >= clientinfo.nproc ) {
    fprintf( stderr, "M6378_Wait(%d): Specified id (%d) is invalid or out of range.\n",
                     clientinfo.rank, id );
    return(0);
  }
  sock = getSocket( id );
  if( sock == -1 ) {
    fprintf( stderr, "M6378_Wait(%d): Could not open socket to %d.\n", clientinfo.rank, id );
    return(0);
  }
  buf = clientinfo.buf;
  /* Send request. */
  sprintf( buf, "%d\n%s:%d\n\n", WAIT, clientinfo.gid, id );
  sz = strlen(buf);
  status = WRITE( sock, buf, sz );
  if( status < sz ) {
    fprintf( stderr, "M6378_Wait(%d): Socket write error.\n", clientinfo.rank );
    return(0);
  }
  FLUSH(sock);
  /* Read response. */
  status = READ( sock, buf, clientinfo.bufsz );  
  if( status < 0 ) {
    fprintf( stderr, "M6378_Wait(%d): Socket read error.\n", clientinfo.rank );
    return(0);
  }
  return(1);
}

/*
 * This example test code uses m6378 mpi routines typed in the header
 * file ../include/m6378.h as follows.
 *   M6378_Init(int*, char**), 
 *   M6378_Comm_size(int*), M6378_Comm_rank(int*), 
 *   M6378_Isend(int, void*, int), M6378_Wait(int), 
 *   M6378_Recv(int, void*, int),
 *   M6378_Finalize().
 * 
 * You must call M6378_Init with its proper &argc, argv arguments before
 * doing any mpi stuff. Call M6378_Comm_size and M6378_Comm_rank to
 * determine how many cooperating processes there are (size) and which one 
 * you are (0 <= rank < size). Please call M6378_Finalize before exiting.
 *
 * This code does four interprocess communication tests.
 * (1) A broadcast from the master process (rank == 0) to all slave
 *     processes (rank > 0).
 * (2) A simple message sent from each process "rank" to its neighbor
 *     "rank+1" mod size. (size = number of cooperating processes.)
 * (3) A gather from all non-master processes to the master.
 * (4) A fairly large data size master gather.
 *
 */

#include "m6378.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

main( int argc, char *argv[] ) {
  int  n, np, myid, id, size;
  char cbuf[1024];
  int sndto, rcvfr;

  M6378_Init( &argc, argv );
  M6378_Comm_size( &np );
  M6378_Comm_rank( &myid );

  if( myid == 0 ) {
    printf( "Master broadcast 1.\n" ); fflush(stdout);
    fflush(stdout);
    for( id = 1; id < np; id++ ) {
      sprintf( cbuf, "Hi to %d from %d.", id, myid );
      M6378_Isend( id, cbuf, strlen(cbuf) );
      M6378_Wait( id );
    }
  }
  else {
    M6378_Recv( 0, cbuf, &size );
    cbuf[size] = '\0';
    printf( "Process %d got message: %s\n", myid, cbuf ); fflush(stdout);
    fflush(stdout);
  }

  sndto = myid+1;
  if( sndto >= np ) sndto = 0;
  rcvfr = myid-1;
  if( rcvfr < 0   ) rcvfr = np-1;
  sprintf( cbuf, "Howdy neighbor from %d.", myid );
  M6378_Isend( sndto, cbuf, strlen(cbuf) );
  M6378_Recv ( rcvfr, cbuf, &size );
  cbuf[size] = '\0';
  printf( "Process %d recv'd: %s\n", myid, cbuf );
  fflush(stdout);
  M6378_Wait( sndto );

  if( myid == 0 ) {
    printf( "Master gather 2.\n" ); fflush(stdout);
    for( id = 1; id < np; id++ ) {
      M6378_Recv( id, cbuf, &size );
      cbuf[size] = '\0';
      printf( "Process %d got message: %s\n", myid, cbuf ); fflush(stdout);
      fflush(stdout);
    }
  }
  else {
    sprintf( cbuf, "Hi to %d from %d.", 0, myid );
    M6378_Isend( 0, cbuf, strlen(cbuf) );
    M6378_Wait( 0 );
  }

# define TESTSIZE 15000

  /* A large transfer test. */
  if( myid == 0 ) {
    int *ibuf;
    ibuf = (int*)malloc( TESTSIZE*sizeof(int) );
    for( id = 1; id < np; id++ ) {
      memset( ibuf, 0, TESTSIZE*sizeof(int) );
      M6378_Recv( id, (char*)ibuf, &size );
      for( n = 0; n < TESTSIZE; n++ ) {
        if( ibuf[n] != n+1+id ) break;
      }
      if( n == TESTSIZE ) {
        printf( "Node %d OK (%d bytes).\n", id, size );
      } else {
        printf( "Problem with node %d.\n", id );
      }
    }
    free( ibuf );
  }
  else {
    int *ibuf;
    ibuf = (int*)malloc( TESTSIZE*sizeof(int) );
    for( n = 0; n < TESTSIZE; n++ ) ibuf[n] = n+1+myid;
    M6378_Isend( 0, (char*)ibuf, TESTSIZE*sizeof(int) );
    M6378_Wait( 0 );
    free( ibuf );
  }


  M6378_Finalize();
  exit(0);
}
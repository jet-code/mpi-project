#ifndef _M6378_H_
#define _M6378_H_

#define PORT 2077
#define SEND 1
#define RECV 2
#define WAIT 3

int  M6378_Init      ( int*, char** );
void M6378_Finalize  ();
int  M6378_Comm_size ( int* );
int  M6378_Comm_rank ( int* );
#ifndef _LIBM6378_C_
int  M6378_Isend     ( int, void*, int );
int  M6378_Recv      ( int, void*, int* );
#endif
int  M6378_Wait      ( int );

#endif /* _M6378_H_ */
